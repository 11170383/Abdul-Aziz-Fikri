package com.hroytekno.latintent2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView


class MainActivity : AppCompatActivity(), View.OnClickListener {

    var i: Int = 0

    override fun onClick(p : View?) {
        var img = findViewById<ImageView>(R.id.imageView8)

            if (i === 1) {
                img.setImageResource(R.drawable.cb1);
                i = 1
            } else {
                img.setImageResource(R.drawable.cb2);
                i = 2
            }

        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        i=1

        val btnMoveActivity : Button = findViewById(R.id.download_logo)
        btnMoveActivity.setOnClickListener(this)

    }
}
